part of 'counter_example_cubit.dart';

@immutable
sealed class CounterExampleState {}

final class CounterExampleInitial extends CounterExampleState {}
